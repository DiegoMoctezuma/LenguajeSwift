//Bucles
//FOR
for i in 1 ... 10 {
    print (i)
}

let numero = 9
for i in 1 ... 9 {
    print(" \(i) x \(numero) = \(i*numero)")
}

//For anidado
for i in 1...5 {
    print("--------------------")
    for j in 1...10 {
        let resultado = i * j
        print("\(i) x \(j) = \(resultado)")
    }
}

//Incremento o decremento personalizado
//Inicio   fin    incremento/decremento
for i in stride(from: 10, to: 0, by: -2) {
    print(i)
}

//WHILE
var contador = 0
while contador < 5 {
    print("El contador es \(contador)")
    contador += 1 // HACER QUE LA CONDICION SE CUMPLA EN ALGUN PUNTO
}

//Repeat
var contadorR = 0
repeat {
    print("El contador R es \(contadorR)")
    contadorR += 1
} while contadorR < 5


//Funciones
func saludar(nombre: String) -> String {
    let mensaje = "Hola, \(nombre)!"
    return mensaje
}

let resultado = saludar(nombre: "Pepe")
print(resultado) // Imprimirá "Hola, Pepe!"

//Funciones sin parametros de retorno
func imprimirMensaje() {
    let nombre: String = "Alberto" // variable local
    print("Hola \(nombre) desde la función")
}
imprimirMensaje() // Llama a la función y muestra "Hola desde la función"

//ENUM
enum EstadoDeConexion {
    case desconectado
    case conectado(red: String)
    case conectadoSinRed
}

var estadoActual = EstadoDeConexion.conectado(red: "Wi-Fi")

switch estadoActual {
case .desconectado:
    print("No hay conexión")
case .conectado(let red):
    print("Conectado a la red: \(red)")
case .conectadoSinRed:
    print("Conectado sin red")
}
print(EstadoDeConexion.conectadoSinRed)

//Struc, parecido a poo
struct Persona {
    var nombre: String
    var edad: Int
    
    func saludar() {
        print("¡Hola! Soy \(nombre) y tengo \(edad) años.")
    }
}

var persona1 = Persona(nombre: "Pepe", edad: 100)
persona1.saludar()
print(persona1.edad)
print(persona1.nombre)


//Sets, valores unicos y sin orden
var numerosPares: Set<Int> = [2, 4, 6, 8, 10]
numerosPares.insert(12)
numerosPares.insert(6) // No se insertará porque ya está en el Set

if numerosPares.contains(8) {
    print("El conjunto contiene el número 8.")
}

var numerosImpares: Set<Int> = [1, 3, 5, 7, 9]

let numerosComunes = numerosPares.intersection(numerosImpares) // Intersección
let todosLosNumeros = numerosPares.union(numerosImpares) // Unión

print(numerosComunes) // Imprimirá los números comunes entre los Sets
print(todosLosNumeros) // Imprimirá todos los números sin duplicados

//EJERCICIOS
print("\n*** Ejercicios ***\n")
//1.Imprime los numeros de 1 al 10 utilizando los ciclos for, while y repeat.
print("\nFor: ")
for i in 1...10 {
    print(i)
}
print("\nWhile: ")
var eContador: Int = 1
while eContador < 11 {
    print(eContador)
    eContador+=1
}
print("\nRepeat: ")
var eRepeat:Int = 1;
repeat{
    print(eRepeat)
    eRepeat+=1
}while eRepeat < 11

//2.Imprime los SOLO los numeros pares del 1 al 20 utilizando el bucle for.
print("\nPares del 1 al 20: ")
for i in stride(from: 0, to: 21, by: 2){
    print(i)
}
//3.Utilizando el bucle for agrega los valores [ 2 , 4 , 6 , 8 , 10] al arreglo
var arreglo : [Int] = []
for i in stride(from: 0, to: 11, by: 2){
    arreglo.append(i)
}
arreglo.remove(at: 0)
print("\nArreglo:")
print(arreglo)

//4.Impime una cuenta regresiva del 10 al 1 usando while
print("\nCuenta regresiva:")
var eWhile:Int = 10
while eWhile > 0 {
    print(eWhile)
    eWhile -= 1
}

//5.Crea una funcion que no reciba parametros llamada nombreCompleto que imprima tu nombre
print("\nFuncion sin parametros:")
func nombreComleto(){
    let eNombres: String = "Diego Rafael"
    let eApellidos: String = "Moctezuma Ramirez"
    print(eNombres,eApellidos)
}
nombreComleto()

//6.Crea una funcion que reciba como parametros tu nombre y apellido e imprima "Hola soy nombre apellido"
print("\nFuncion con parametros: ")
func eSaludar(nombre:String, apellido:String) -> String{
    var eMensaje: String = "Hola soy \(nombre) \(apellido)!"
    return eMensaje
}
var eResultado:String = eSaludar(nombre: "Rafael", apellido: "Moctezuma")
print(eResultado)

//7.Crea una funcion que reciba como paramatros la base y altura de un triangulo y regrese el area como valor de retorno
func areaTriangulo(base:Double,altura:Double) -> Double {
    var eAreaTri: Double = (base * altura)/2
    return eAreaTri
}
var areaResult: Double = areaTriangulo(base: 2.8, altura: 2.5)
print("\nArea del triangulo: \(areaResult)")

//8.Crea una estructura llamada estudiante con todos sus atributos.
print("\nEstructura, estudihambre:")
struct Estudiante{
    var nombre:String
    var edad:Int
    var carrera:String
    var semestre:Int
    var promedio:Double
    var titulado:Bool
}
var eEstudiante1 = Estudiante(nombre: "Rafael", edad: 20, carrera:"MAC", semestre: 1, promedio: 3.4, titulado: false)
print("Nombre: \(eEstudiante1.nombre)\nEdad: \(eEstudiante1.edad)")
print("Carrera: \(eEstudiante1.carrera)\nSemestre: \(eEstudiante1.semestre)")
print("Promedio: \(eEstudiante1.promedio)\nTitulado: \(eEstudiante1.titulado ?"Si":"No")")

//9.Crea un set con los numeros del 1 al 10
var eSetsNum: Set<Int> = [1,2,3,4,5,6,7,8,9,10]
print("\nSets 1 a 10: \(eSetsNum)")

//10.Revisa si el numero 7 esta en el set
if eSetsNum.contains(7){
    print("\nEl numero 7 esta en el set")
}else{
    print("El numero 7 no esta en el set")
}

//11.Con las variables: Encuentra la union y la interseccion de a con b
let a : Set<Int> = [4, 5, 8, 9]
let b : Set<Int> = [3, 4, 5, 7]

var eUnion = a.union(b)
var eInterseccion = a.intersection(b)
print("\nLa union es: \(eUnion)")
print("La interseccion es: \(eInterseccion)")

//TAREA: Funcion para calcular las areas de distintas figuras geometricas
