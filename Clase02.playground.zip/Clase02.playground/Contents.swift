//Operadores aritmeticos
//Suma
let suma = 5 + 3 // Resultado: 8
let a = 2
let b = 3
let c = a + b

//Resta
let resta = 10 - 4 // Resultado: 6
let x = 8
let y = 3
let z = x - y

//Multiplicacion
let multiplicacion = 3 * 7 // Resultado: 21
let multi = 3 * 3 // Resultado: 9

//Division
let division = 15 / 3 // Resultado: 5
let div = 16 / 4 // Resultado: 4

//Modulo
let modulo = 17 % 5 // Resultado: 2

//Compuesto (Aritmetico y de asignacion)
var valor = 10
valor += 5 // Equivalente a valor = valor + 5
valor *= 2 // Equivalente a valor = valor * 2

//Potencia
//let potencia = 2 ** 3 // Resultado: 8


//Operadores logicos

//AND
let a2 = true
let b2 = false
let result = a2 && b2 // Resultado: false

//OR
let x2 = true
let y2 = false
let resultado = x2 || y2 // Resultado: true

//NOt
let condicion = true
let negacion = !condicion // Resultado: false



//Operadores de comparacion

//Igual
let num1 = 5
let num2 = 5
let igualdad = num1 == num2 // Resultado: true

//Diferente
let val1 = "hola"
let val2 = "mundo"
let esDiferente = val1 != val2 // Resultado: true

//Mayor que
let a3 = 10
let b3 = 5
let esMayor = a > b // Resultado: true

//Menor que
let x3 = 3.14
let y3 = 4.0
let esMenor = x < y // Resultado: true

//Mayor igual que
let valor1 = 8
let valor2 = 8
let esMayorIgual = valor1 >= valor2 // Resultado: true

//Menor igual que 
let m = 20
let n = 25
let esMenorIgual = m <= n // Resultado: true


/**  ARREGLOS **/

//Definicion
var numeros: [Int] = [1, 2, 3, 4, 5, 6, 7, 8, 9]
var nombres: [String] = ["Pepe", "Carlos", "Ana"]


//Acceso
let primerNumero = numeros[0] // primerNumero es 1
let segundoNombre = nombres[1] // segundoNombre es "Juan"

//Modificacion
numeros[2] = 10 // Cambiar el tercer elemento a 10
nombres[2] = "Ana María" // Cambiar el primer nombre

//Longitud
let cantidadNombres = nombres.count // cantidadNombres es 3
let cantidadNumeros = numeros.count // cantidad 9

//Agregar eliminar
numeros.append(6) // Agregar el número 6 al final
nombres.remove(at: 1) // Eliminar el segundo nombre

//Iteracion
for numero in numeros {
 print(numero)
}

nombres.forEach { nombre in
print("Hola, \(nombre)!")
}

//Ordenamiento
var numerosDesordenados = [3, 1, 4, 2]
let numerosOrdenados = numerosDesordenados.sorted() // Devuelve un nuevo arreglo ordenado
numerosDesordenados.sort() // Ordena el arreglo original


/**  CONDICIONALES **/

//IF
let numeroX = 20
if ( numeroX > 0 ) {
    print ("El numero es positivo")
}

//ELSE
let numeroY = -10

if numeroY > 0 {
    print("El número es positivo")
} else {
    print("El número es negativo")
}

//ELSE IF (para no anidar los if's)
let temperatura = 25
if temperatura > 30 {
    print("Hace mucho calor.")
} else if temperatura > 20 {
    print("El clima es agradable.")
} else {
    print("Hace un poco de frío.")
}

//Operador ternario
let numeroA = 7
let resultadoX = numeroA > 5 ? "Es mayor que 5" : "No es mayor que 5"
print(resultado)

//Switch
let numeroQ = 0
switch numeroQ {
case 0:
    print("El número es cero")
case 1:
    print("El número es uno")
case 2, 3:
    print("El número es dos o tres")
default:
    print("El número es otro valor")
}

let caracter: Character = "B"
switch caracter {
case "a", "A":
    print("El caracter es 'a' o 'A'")
case "b", "B":
    print("El caracter es 'b' o 'B'")
default:
    print("El caracter no es 'a', 'A', 'b' ni 'B'")
}

/** EJERCICIOS **/
print("\n*** EJERCICIOS ***\n")

//1. Con las siguientes variables, realiza tres operaciones aritmeticas y tres operaciones de comparación.
let eNumero1 = 7
let eNumero2 = 11
//Aritmeticas
var eSuma = eNumero1 + eNumero2
print("Suma de \(eNumero1) + \(eNumero2) = \(eSuma)")
var eResta = eNumero1 - eNumero2
print("Resta de \(eNumero1) - \(eNumero2) = \(eResta)")
var eMult = eNumero1 * eNumero2
print("Multiplicacion de \(eNumero1) * \(eNumero2) = \(eMult)")
//Comparacion
var eIgual = eNumero1 == eNumero2
print("\(eNumero1) == \(eNumero2) : \(eIgual)")

var eMayor = eNumero1 > eNumero2
print("\(eNumero1) > \(eNumero2) : \(eMayor)")

var eMenor = eNumero1 < eNumero2
print("\(eNumero1) < \(eNumero2) : \(eMenor)")

//2. Declara un arreglo de enteros con mas de 5 elementos.
var eArreglo: [Int] = [1, 43, 657, 65, 78, 9854, 54, 90]

//3. Encuentra el numero de elementos del arreglo.
var elementos = eArreglo.count
print("Elementos del arreglo: \(elementos)")

//4. Imprime el arreglo ordenado utilizando el metodo sorted()
var eOrdenado = eArreglo.sorted()
print("Arreglo ordenado: \(eOrdenado)")

//5. Agrega dos elementos al arreglo
eOrdenado.append(99)
eOrdenado.append(101)
print("Elementos agregados: \(eOrdenado)")

//6. Elimina el tercer elemento del arreglo
eOrdenado.remove(at: 2)
print("3er elemento eliminado: \(eOrdenado)")

//7. Con las variables, si 'a' es mas grande que 'b' imprime un mensaje que diga "A es mas grande que B" con if
let eA = 4
let eB = 3
if eA > eB {
    print("A es mas grande que B")
}

//8. En una variable declara tu edad y utilizando el operador ternario determina si eres mayor de 21 o no impreso en pantalla
var eEdad = 20
var eMayorEdad = eEdad > 21 ? "Tienes mas de 21 años" : "Tienes menos de 21 años"
print(eMayorEdad)

//9. Haz una estructura elseIf para cada variable siguiente donde se determine si un numero es positivo, negativo o es cero.
let eNum1 = 3
let eNum2 = -4
//1
if(eNum1 > 0){
    print("El numero es positivo")
}else if(eNum1 < 0){
    print("El numero es negativo")
}else {
    print("El numero es igual a cero")
}
//2
if(eNum2 > 0){
    print("El numero es positivo")
}else if(eNum2 < 0){
    print("El numero es negativo")
}else {
    print("El numero es igual a cero")
}

//10.Crea una estructura switch para para determinar si el clima es agradable con los casos:
let clima = "Soleado"

switch clima {
case "Soleado":
    print("Dia agradable")
case "Nublado", "Lloviendo":
    print("Dia no agradable")
default:
    print("Caso invalido")
}
