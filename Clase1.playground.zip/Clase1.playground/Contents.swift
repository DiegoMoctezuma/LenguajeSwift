import UIKit
import Foundation

var saludo = "Hola Mundo"

//1.- En un comentario de una linea escribe tu nombre de pila
//Diego


//2.En un comentario multilinea escribe tu nombre de pila, tu carrera y tu edad
/*
 Nombre: Diego
 Carrera: MAC
 Edad: 20
 */


//3.-Declara una variable de tipo string, booleano y entero y asigna un valor para cada una/
var cadena: String = "Hola"
var booleano: Bool = true
var entero: Int = 10


//4.-Declara 4 variables sin asignarles un valor
var uno: String?
var dos: Bool?
var tres: Int?
var cuatro: Double?


//5.-Declara 4 variables de cualquier tipo y asigna un valor para cada una de ellas
var escuela: String = "FES A"
var semestre: Int = 1
var titulado: Bool = false
var promedio: Double = 9.9999


//6.-Declara las variables necesarias para almacenar tu nombre de pila, tu apellido , tu edad diferenciando entre var y let
let nombre: String = "Diego"
let apellido: String = "Moctezuma"
var edad: Int = 20
